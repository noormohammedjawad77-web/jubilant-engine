TotemGuard 1.0.0
Build:  mvn clean package   ->  target/TotemGuard-1.0.0.jar
Load:   plm load TotemGuard   (or restart)
Config: plugins/TotemGuard/config.yml  (protect-ticks)
If the build can't find Paper 26.2, change <paper.version> in pom.xml.
