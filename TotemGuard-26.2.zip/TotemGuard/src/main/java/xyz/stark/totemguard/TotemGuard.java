package xyz.stark.totemguard;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TotemGuard extends JavaPlugin implements Listener {

    private int protectTicks;
    private final Map<UUID, Integer> protectedUntil = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        protectTicks = Math.max(1, getConfig().getInt("protect-ticks", 2));
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    // لحظة اشتغال التوتم فعلاً
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPop(EntityResurrectEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        protectedUntil.put(p.getUniqueId(), Bukkit.getCurrentTick() + protectTicks);
    }

    // أي ضرر خلال نافذة الحماية يتلغى بصمت (بدون رسالة ولا مؤثرات)
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;

        Integer until = protectedUntil.get(p.getUniqueId());
        if (until == null) return;

        // لا نلغي /kill أو الـ Void
        EntityDamageEvent.DamageCause c = e.getCause();
        if (c == EntityDamageEvent.DamageCause.KILL
                || c == EntityDamageEvent.DamageCause.VOID
                || c == EntityDamageEvent.DamageCause.WORLD_BORDER) return;

        if (Bukkit.getCurrentTick() <= until) {
            e.setCancelled(true);
        } else {
            protectedUntil.remove(p.getUniqueId());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        protectedUntil.remove(e.getPlayer().getUniqueId());
    }
}
